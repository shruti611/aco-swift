import SwiftUI

struct ContentView: View {
    
    @State var showSecondView = false

    func goToSecondView() {
        // Set up your second screen content here (e.g., another view)
        showSecondView = true
    }
    
    
    var body: some View {
        if !showSecondView {
            ZStack {
                 RadialGradient(gradient: Gradient(colors: [Color.yellow, Color.orange]), center: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, startRadius: /*@START_MENU_TOKEN@*/5/*@END_MENU_TOKEN@*/, endRadius: /*@START_MENU_TOKEN@*/500/*@END_MENU_TOKEN@*/)
                
                VStack {
                    //Ant 1
                    Image("ant")
                        .resizable()
                        .frame(width: 80, height: 80)
                        .offset(x:200,y:100)
                        .foregroundColor(.accentColor)


                    //Ant 2
                    Image("ant")
                        .resizable()
                        .frame(width: 80, height: 80)
                        .rotationEffect(.degrees(60))
                        .offset(x:0,y:-10)
                        .foregroundColor(.accentColor)
                    //Ant 3
                    Image("ant")
                        .resizable()
                        .frame(width: 80, height: 80)
                        .rotationEffect(.degrees(270))
                        .offset(x:-200,y:-200)
                        .foregroundColor(.accentColor)
                    
                    Text("Ant Colony Optimization")
                        .fontWeight(.black)
                        .fontWidth(.standard)
                        .font(.largeTitle)
                        .fontDesign(.serif).multilineTextAlignment(.center)
                    
                    Button("Lets start learning") {
                        goToSecondView()
                    }.font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/).tint(Color.white).fontDesign(.serif).multilineTextAlignment(.center)
                    
                    //Ant 4
                    Image("ant")
                        .resizable()
                        .frame(width: 80, height: 80)
                        .rotationEffect(.degrees(90))
                        .offset(x:-90,y:100)
                        .foregroundColor(.accentColor)
                    //Ant 5
                    Image("ant")
                        .resizable()
                        .frame(width: 80, height: 80)
                        .rotationEffect(.degrees(146))
                        .offset(x:200,y:-100)
                        .foregroundColor(.accentColor)
                    //Ant 6
                    Image("ant")
                        .resizable()
                        .frame(width: 80, height: 80)
                        .rotationEffect(.degrees(350))
                        .offset(x:200,y:170)
                        .foregroundColor(.accentColor)
                    //Ant 7
                    Image("ant")
                        .resizable()
                        .frame(width: 80, height: 80)
                        .rotationEffect(.degrees(100))
                        .offset(x:-200,y:170)
                        .foregroundColor(.accentColor)
                    Image("ant")
                        .resizable()
                        .frame(width: 80, height: 80)
                        .rotationEffect(.degrees(100))
                        .offset(x:300,y:-770)
                        .foregroundColor(.accentColor)
                    }
                
            }
        }
        else{
            SecondView()
        }

    }
}


struct ContentView_Preview:PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}



