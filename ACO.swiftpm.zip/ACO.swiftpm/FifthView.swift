import SwiftUI

struct FifthView: View {
    let color: Color = .black // Adjust the color as needed
    let lineWidth: CGFloat = 2.0
    @State var showView = 5
    
    var body: some View {
        if showView == 5 {
            ZStack {
                RadialGradient(gradient: Gradient(colors: [Color.yellow, Color.orange]), center: .center, startRadius: 5, endRadius: 500)
                
                Path { path in
                    path.move(to: CGPoint(x: 0, y: 0))
                    path.addQuadCurve(to: CGPoint(x: 500, y: 400), control: CGPoint(x: 10, y: 500))
                    path.addQuadCurve(to: CGPoint(x: 100, y: 1200), control: CGPoint(x: 20, y: 10))
                    path.addQuadCurve(to: CGPoint(x: 500, y: 12), control: CGPoint(x: 200, y: 300))
                    path.addQuadCurve(to: CGPoint(x: -10, y: 300), control: CGPoint(x: 200, y: 300))
                    path.addQuadCurve(to: CGPoint(x: 500, y: 800), control: CGPoint(x: 20, y: 100))
                    path.addQuadCurve(to: CGPoint(x: 0, y:700 ), control: CGPoint(x: 200, y: 800))
                   
                }
                .stroke(style: StrokeStyle(lineWidth: lineWidth, dash: [5, 5])) // Set dash length and gap
                .foregroundColor(color)
                
                VStack {
                    Text("Maya's Wit")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .fontDesign(.serif)
                        .multilineTextAlignment(.center) 
                    
                    Divider()
                    
                    HStack{
                        Image("ant")
                            .resizable()
                            .offset(x:-15,y:-20)
                            .frame(width: 40, height: 40).rotationEffect(.degrees(290))
                        Spacer()
                    }
                    HStack{
                        Spacer()
                        Image("ant")
                            .resizable()
                            .frame(width: 40, height: 40).rotationEffect(.degrees(180))
                    }
                    
                    Spacer()
                    
                    Text("She wouldn't blindly wander. Instead, she'd set out with her sisters, each exploring different paths. \n\nAs they journeyed, they'd lay down a pheromone trail, a fragrant message marking their way. \n\nThe stronger the scent, the tastier the berries found there.")
                        .font(.title)
                        .fontDesign(.serif)
                        .multilineTextAlignment(.center)
                        .padding(.bottom)
                    
                    HStack{
                        Spacer()
                        Image("ant")
                            .resizable()
                            .offset(x:-20,y:-30)
                            .frame(width: 40, height: 40).rotationEffect(.degrees(80))
                    }
                    HStack{
                        
                        Image("ant")
                            .resizable()
                            .offset(x:10,y:-100)
                            .frame(width: 40, height: 40).rotationEffect(.degrees(80))
                        Spacer()
                    }
                    
                    HStack{
                        Image("anthill")
                            .resizable()
                            .frame(width: 150, height: 150)
                            .frame(alignment: .leading)
                        Spacer()
                        
                    }
                    
                    
                    Spacer()
                    // Previous button positioned at bottom left corner
                    
                    HStack {
                        Button(action: {
                            showView = 4                       }) {
                                Text("Previous")
                            }
                            .font(.title3)
                            .fontWeight(.bold)
                            .padding()
                            .background(Capsule().foregroundColor(.orange))
                        
                        Spacer()
                        
                        Button(action: {
                            showView = 6
                        }) {
                            Text("Next")
                        }
                        .font(.title3)
                        .fontWeight(.bold)
                        .padding()
                        .background(Capsule().foregroundColor(.orange))
                        
                        
                        
                    }
                }
                .padding()
            }
        } else if showView == 4 {
            FourthView()
        }
        else if showView == 6{
            
        }
    }
}

struct FifthView_Preview: PreviewProvider {
    static var previews: some View {
        FifthView()
    }
}

