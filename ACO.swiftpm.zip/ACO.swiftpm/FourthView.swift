import SwiftUI

struct FourthView: View {
    @State var showView = 4
    
    var body: some View {
        if showView == 4 {
            ZStack {
                RadialGradient(gradient: Gradient(colors: [Color.yellow, Color.orange]), center: .center, startRadius: 5, endRadius: 500)
                
                VStack {
                    Text("Protaganist")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .fontDesign(.serif)
                        .multilineTextAlignment(.center) 
                    
                    Divider()
                    
                    Text("Imagine Maya, a young, enthusiastic ant, tasked with finding the juiciest patch of berries.")
                        .font(.title)
                        .fontDesign(.serif)
                        .multilineTextAlignment(.center)
                        .padding(.bottom)
                    Spacer()
                    Image("ant")
                        .resizable()
                        .frame(width: 300, height: 300)
                    
                    Spacer()
                    
                    
                    
                    // Previous button positioned at bottom left corner
                    
                    HStack {
                        Button(action: {
                            showView = 3                        }) {
                            Text("Previous")
                        }
                        .font(.title3)
                        .fontWeight(.bold)
                        .padding()
                        .background(Capsule().foregroundColor(.orange))
                        
                        Spacer()
                        
                        Button(action: {
                            showView = 5
                        }) {
                            Text("Next")
                        }
                        .font(.title3)
                        .fontWeight(.bold)
                        .padding()
                        .background(Capsule().foregroundColor(.orange))
                        
                        
                        
                    }
                }
                .padding()
            }
        } else if showView == 3 {
            ThirdView()
        }
        else if showView == 5{
            FifthView()
            
        }
    }
}

struct FourthView_Preview: PreviewProvider {
    static var previews: some View {
        FourthView()
    }
}
