import SwiftUI


struct RoughView:View{
    var body: some View {
        ZStack{
            Image("ACO_1") // Replace "backgroundImage" with your image name
                .resizable()
                .ignoresSafeArea()
                .aspectRatio(contentMode: .fill)
            
        }
        
    }
}

struct RoughView_Preview:PreviewProvider {
    static var previews: some View {
        RoughView()
    }
}
