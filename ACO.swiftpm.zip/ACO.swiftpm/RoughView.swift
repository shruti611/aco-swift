import SwiftUI


struct RoughView:View{
    var body: some View {
        ZStack{
            Image("ACO_1") // Replace "backgroundImage" with your image name
                .resizable()
                .ignoresSafeArea()
                .aspectRatio(contentMode: .fill)
            
        }
        
    }
}

struct RoughView_Preview:PreviewProvider {
    static var previews: some View {
        RoughView()
    }
}

/*
 In the bustling anthill of Optimazia, lived a colony unlike any other.Here, ants weren't just content with crumbs; they craved the sweetest, most efficient solutions to every challenge. Their secret weapon? Ant Colony Optimization. A dance of collaboration and discovery. 
 Imagine Maya, a young, enthusiastic ant, tasked with finding the juiciest patch of berries.She wouldn't blindly wander. Instead, she'd set out with her sisters, each exploring different paths. As they journeyed, they'd lay down a pheromone trail, a fragrant message marking their way. The stronger the scent, the tastier the berries found there.
 Maya and her sisters, a synchronized ballet of industrious ants, set forth, their antennae twitching with anticipation. They spread out, each taking a different path, their tiny legs carrying them through the dense undergrowth. Maya, small but determined, pushed through a network of roots, her heart pounding with the thrill of exploration.
 Their journey wasn't easy. Thorny bushes snagged their legs, and the scent of ripe berries often led them astray to empty patches. But Maya persevered, guided by the faint pheromone trail left by her sisters. As she ventured deeper, the scent grew stronger, a sweet promise carried on the wind.
 Suddenly, another ant, weary and lost, stumbled onto Maya's path. Maya, remembering the colony's motto of "Strength in Unity," pointed her antenna towards the source of the stronger scent. The lost ant, grateful for the guidance, followed Maya, their steps echoing in unison as they hurried towards the promised bounty.
 Finally, they emerged into a clearing bathed in sunlight. Before them, nestled amongst vibrant leaves, lay a cluster of berries, plump and ripe, exuding a fragrance that made Maya's mandibles twitch with delight. News spread like wildfire through the colony via the pheromone trail. Soon, it was a flurry of activity as ants, guided by the collective knowledge, gathered the harvest.
 That evening, under the warm glow of the moon, the colony feasted. Maya, surrounded by her sisters, felt a surge of pride. They hadn't just found the juiciest patch; they had found a way to work together, to share information, to optimize their efforts. They were, after all, the ants of Optimazia, and their journey was just beginning.
 However, their success wasn't without challenges. A rival colony, envious of their efficiency, plotted to steal their prize. What would Maya and her sisters do to protect their newfound bounty? Could they use their ant colony optimization to outsmart the competition and continue thriving in the ever-changing forest? The story of optimization continues...
*/
