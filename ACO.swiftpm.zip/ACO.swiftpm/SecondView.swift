import SwiftUI


struct SecondView:View{
    @State var showThirdView = false
    
    func goToThirdView() {
        // Set up your second screen content here (e.g., another view)
        showThirdView = true
    }
    @State private var imagePosition: CGPoint = CGPoint(x: 400, y: 400)
    func moveImageTo(_ newPosition: CGPoint, duration: TimeInterval) {
        UIView.animate(withDuration: duration, animations: {
            self.imagePosition = newPosition
        })
    }

    
    var body: some View {
        if !showThirdView {
            ZStack{
                RadialGradient(gradient: Gradient(colors: [Color.yellow, Color.orange]), center: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, startRadius: /*@START_MENU_TOKEN@*/5/*@END_MENU_TOKEN@*/, endRadius: /*@START_MENU_TOKEN@*/500/*@END_MENU_TOKEN@*/)
                
                VStack {
                    Text("Anty Way").font(.largeTitle).fontWeight(.bold).fontDesign(.serif).padding()
                    
                    Divider()
                    
                    VStack(){
                        
                        Text("Have you ever observed an ant trail?").font(.title).fontWeight(.medium).fontDesign(.serif).padding().multilineTextAlignment(.center)
                        
                        HStack {
                            Image("ant")
                                .resizable()
                                .frame(width: 80, height: 80).rotationEffect(.degrees(45))
                                .foregroundColor(.accentColor)
                            Image("ant")
                                .resizable()
                                .frame(width: 80, height: 80).rotationEffect(.degrees(45))
                                .foregroundColor(.accentColor)
                            Image("ant")
                                .resizable()
                                .frame(width: 80, height: 80).rotationEffect(.degrees(45))
                                .foregroundColor(.accentColor)
                            Image("ant")
                                .resizable()
                                .frame(width: 80, height: 80).rotationEffect(.degrees(45))
                                .foregroundColor(.accentColor)
                            
                        }.padding()
                        
                        Text("It's not just a path, it's a whispered code.\n\n \n").font(.title).fontWeight(.medium).fontDesign(.serif).padding().multilineTextAlignment(.center)
                        
                        Text("\nLet's decode the ant trail's dance. It's an optimization trance.")
                            .font(.title)
                            .fontWeight(.medium)
                            .fontDesign(.serif)
                            .padding()
                            .multilineTextAlignment(.center)
                        
                        Text("\n\nDear Adventurer, Lets go to...")
                            .fontWeight(.medium)
                            .font(.title)
                            .fontDesign(.serif)
                            .padding()
                            .multilineTextAlignment(.center)
                        
                        
                        Text("Optimazia")
                            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                            .font(.largeTitle)
                            .fontDesign(.serif)
                            .padding()
                            .multilineTextAlignment(.center)
                        
                        Button("GO") {
                            goToThirdView()
                        }.background(Circle().frame(width: 50, height: 50)).tint(.orange)
                            
                        
                        
                    }
                    
                    
                    Spacer()
                }
                
                
                //            Image("Sugar")
                //                .resizable()
                //                .frame(width: 40, height: 40)
                //                .position(imagePosition)
                //                .onTapGesture {
                //                    moveImageTo(CGPoint(x: 100, y: 100), duration: 3)
                //                }
                
                
                
                
            }
        } else {
            ThirdView()
        }
    }
}

struct SecondView_Preview:PreviewProvider {
    static var previews: some View {
        SecondView()
    }
}
