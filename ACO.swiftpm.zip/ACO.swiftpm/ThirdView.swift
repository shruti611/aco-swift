import SwiftUI

struct ThirdView: View {
    @State var showFourthView = false
    
    func goToFourthView() {
        // Set up your fourth screen content here (e.g., another view)
        showFourthView = true
    }
    
    var body: some View {
        if !showFourthView {
            ZStack {
                RadialGradient(gradient: Gradient(colors: [Color.yellow, Color.orange]), center: .center, startRadius: 5, endRadius: 500)
                
                VStack {
                    Text("Welcome to Optimazia")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .fontDesign(.serif)
                        .multilineTextAlignment(.leading) // Left-align individual lines
                    
                    Divider()
                    
                    Image("anthill")
                        .resizable()
                        .frame(width: 400, height: 300)
                    
                    Text("In the bustling anthill of Optimazia, lived a colony unlike any other. \n\nHere, ants weren't just content with crumbs; they craved the sweetest, most efficient solutions to every challenge. \n\nTheir secret weapon? \n\n")
                        .font(.title)
                        .fontDesign(.serif)
                        .multilineTextAlignment(.center)
                    
                    Text("Ant Colony Optimization")
                        .font(.largeTitle)
                        .fontDesign(.serif)
                        .multilineTextAlignment(.center)
                    
                    Text("A dance of collaboration and discovery")
                        .font(.title2)
                        .fontWeight(.regular)
                        .fontDesign(.serif)
                        .multilineTextAlignment(.center)
                        .padding()
                    
                    Spacer()
                    
                    // Next button positioned at bottom right corner
                    
                    HStack {
                        Spacer()
                        Button("Next") {
                            goToFourthView()
                        }
                        .font(.title3)
                        .fontWeight(.bold)
                        .padding()
                        .background(Capsule().foregroundColor(.orange))
                    }
                }
                .padding()
            }
        } else {
            FourthView()
        }
    }
}

struct ThirdView_Preview: PreviewProvider {
    static var previews: some View {
        ThirdView()
    }
}
